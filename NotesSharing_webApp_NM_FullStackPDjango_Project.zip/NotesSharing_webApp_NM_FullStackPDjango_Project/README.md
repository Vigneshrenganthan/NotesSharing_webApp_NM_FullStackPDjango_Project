# NotesSharing_webApp_NM_FullStackPDjango_Project

Project Developed by:

Mention your name
Regnumber , college name....


Login credentials:


Username: admin

Password: admin
